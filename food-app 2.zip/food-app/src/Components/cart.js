// import React from 'react';
// import { useSelector, useDispatch } from 'react-redux';
// import { removeFromCart, updateQuantity } from '../actions/cartAction';
//
// const Cart = () => {
//     const cartItems = useSelector((state) => state.cart.items);
//     const dispatch = useDispatch();
//
//     const handleRemoveFromCart = (productId) => {
//         dispatch(removeFromCart(productId));
//     };
//
//     const handleUpdateQuantity = (productId, newQuantity) => {
//         dispatch(updateQuantity(productId, newQuantity));
//     };
//
//     const calculateTotalPrice = () => {
//         return cartItems.reduce((total, item) => total + item.price * item.quantity, 0);
//     };
//
//     return (
//         <div className="cart">
//             <h2>Shopping Cart</h2>
//             <ul>
//                 {cartItems.map((item) => (
//                     <li key={item.id}>
//                         {item.name} - Quantity: {item.quantity} - Total: {item.quantity * item.price} USD
//                         <p>{item.description}</p>
//                         <button onClick={() => handleRemoveFromCart(item.id)}>Remove from Cart</button>
//                         <button onClick={() => handleUpdateQuantity(item.id, item.quantity + 1)}>+</button>
//                         <button onClick={() => handleUpdateQuantity(item.id, item.quantity - 1)}>-</button>
//                     </li>
//                 ))}
//             </ul>
//             <p>Total Price: {calculateTotalPrice()} USD</p>
//         </div>
//     );
// };
//
// export default Cart;