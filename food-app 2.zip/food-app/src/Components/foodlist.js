import React, { useEffect ,useState} from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
    fetchFoodItems,
    fetchFoodOrderProducts,
    deleteFoodItem,
    updateFoodcart,
    addFoodcart
} from '../actions/foodActions';
import  '../index.css';
import { addToCart,updateQuantity, removeFromCart } from '../actions/cartAction';


const ProductList = () => {
    const dispatch = useDispatch();
    const products = useSelector((state) => state.productlist.products);
    const cartItems = useSelector((state) => state.cart.items);

    useEffect(() => {
        dispatch(fetchFoodOrderProducts());
        dispatch(fetchFoodItems());

        console.log(cartItems,'cartItems');
    }, [dispatch]
    );


    const handleAddToCart = (item) => {
        const cartItem = cartItems.find((cartItem) => cartItem._id === item._id);
        if (cartItem) {
            dispatch(updateQuantity(cartItem._id, cartItem.quantity + 1));
            dispatch(updateFoodcart(cartItem._id, cartItem.quantity + 1,cartItem.price))
        } else {
            const newItem = { ...item, quantity: 1 };
            dispatch(addToCart(newItem));
            dispatch(addFoodcart(newItem));
        }

    };

    const removeCartItem = (item) => {
        dispatch(removeFromCart(item._id))
        dispatch(deleteFoodItem(item._id))
    }

    const handleIncrement = (item) => {
        dispatch(updateQuantity(item._id, (item.quantity ? item.quantity : 0) + 1));
        dispatch(updateFoodcart(item, (item.quantity ? item.quantity : 0) + 1));
    };

    const handleDecrement = (item) => {
        if (item.quantity > 1) {
            dispatch(updateQuantity(item._id, item.quantity - 1));
            dispatch(updateFoodcart(item, item.quantity - 1))
        }
    };

    const calculateTotalPrice = () => {
        return cartItems.reduce((total, item) =>
            total + item.price * item.quantity,
            0);
    };

    return (
        <div className="home-page">
            <h1>Food App</h1>
            <div className="cart">
                <h2>Cart list({cartItems && cartItems.length})</h2>
                <ul>
                    {cartItems.map((item,index) => (
                        <li key={item._id * index}>
                            {item.name} - Amount: {item.quantity * item.price}
                            <button onClick={() => handleIncrement(item)}>+</button>
                            {' '} { item.quantity}
                            <button onClick={() => handleDecrement(item)}>-</button>
                            <button onClick={() => removeCartItem(item)}>Delete</button>
                        </li>
                    ))}
                </ul>
                {cartItems.length > 0 &&  <p>Total Price: ₹{calculateTotalPrice()} </p>}

            </div>
            <div className="product-list">

                {products && products.map((product) => (
                    <div key={product._id} className="product-card">
                          <h2>{product.name}</h2>
                      <p><b>Price:</b> ₹{product.price}</p>
                        <button className="add-to-cart-button" onClick={() => handleAddToCart(product)}>
                            ADD
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );

};

export default ProductList;
