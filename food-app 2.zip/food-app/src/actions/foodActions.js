import axios from 'axios';
import {addToCart} from "./cartAction";

export const fetchFoodItems = () => {
    return async (dispatch) => {
        try {
            const response = await axios.get('http://localhost:3000/api/food-list');
            dispatch({ type: 'SUCCESS', payload: response.data });
        } catch (error) {
            dispatch({ type: 'ERROR', payload: error.message });
        }
    };
};

export const fetchFoodOrderProducts = () => {
    return async (dispatch) => {
        try {
            const response = await axios.get('http://localhost:3000/api/cart-list');
            const items = response.data;
            const newItems = [];
            items.forEach((item) => {
                const newItem = { ...item.order_details };
                newItems.push(newItem);
            });
            console.log(newItems,'newItems');
            dispatch({ type: 'ADD_TO_CART', payload: newItems });

        } catch (error) {
            dispatch({ type: 'ERROR', payload: error.message });
        }
    };
};

export const deleteFoodItem = (id) => {
    console.log(id,'ididid');
    return async (dispatch) => {
        try {
             await axios.post('http://localhost:3000/api/delete-cart-item',{id:id});
        } catch (error) {
            dispatch({ type: 'ERROR', payload: error.message });
        }
    };
};

export const updateFoodcart = (item,quantity) => {

    return async (dispatch) => {
        console.log(item,quantity,'id,quantity,price')
        try {
            await axios.post('http://localhost:3000/api/update-cart-item',{id:item._id,quantity:quantity,price:item.price});
        } catch (error) {
            dispatch({ type: 'ERROR', payload: error.message });
        }
    };
};
export const addFoodcart = (item) => {
    return async (dispatch) => {
        try {
             await axios.post('http://localhost:3000/api/add-cart-item',{item:item});
        } catch (error) {
            dispatch({ type: 'ERROR', payload: error.message });
        }
    };
};