const initialState = {
    items: [],
};

const cartReducer = (state = initialState, action) => {
    switch (action.type) {
        case 'ADD_TO_CART':
            let newItems;
            if (Array.isArray(action.payload)) {
                newItems = [...state.items, ...action.payload];
            } else if (typeof action.payload === 'object') {
                newItems = [...state.items, action.payload];
            } else {
                newItems = state.items;
            }
            return {
                ...state,
                items: newItems,
            };

        case 'REMOVE_FROM_CART':
            return {
                ...state,
                items: state.items.filter((item) => item._id !== action.payload)
            };

        case 'UPDATE_QUANTITY':
            return {
                ...state,
                items: state.items.map((item) =>
                    item._id === action.payload.productId
                        ? { ...item, quantity: action.payload.newQuantity }
                        : item
                ),
            }
        default:
            return state;
    }
};

export default cartReducer;
