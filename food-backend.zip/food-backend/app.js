
const express = require('express');
const app = express();
const mongoose = require('mongoose');
const FoodList = require('./models/food_lists');
const CartList = require('./models/cartlist');
const cors = require('cors');

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/Food', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

app.use(cors());
app.use(express.json());

// get food list
app.get('/api/food-list', async (req, res) => {
    try {
       const list = await FoodList.find();
        res.json(list);
    } catch (err) {
        res.status(500).json({ error: 'Internal server error' });
    }

});

// get cart items
app.get('/api/cart-list', async (req, res) => {
        try {
            const ordersWithProducts = await CartList.aggregate([
                {
                    $lookup: {
                        from: 'food_lists',
                        localField: 'food_id',
                        foreignField: '_id',
                        as: 'order_details',
                    },
                },
                {
                    $unwind: '$order_details',
                },
                {
                    $addFields: {
                        'order_details.food_id': '$food_id',
                        'order_details.quantity': '$quantity',
                        'order_details.date': '$date',
                        'order_details.price': '$order_details.price',
                    },
                },
                {
                    $project: {
                        _id: 1,
                        order_details: 1,
                    },

                },
            ]);
            res.json(ordersWithProducts);
        } catch (err) {
            res.status(500).json({ error: 'Internal server error' });
        }
    });

// delete food from cart
app.post('/api/delete-cart-item', async (req, res) => {

      try {
           const { id } = req.body;
          console.log(req.body);
           const result = await CartList.deleteOne({ food_id: id });
          res.json(req.body);
      }
      catch (e){
          console.log(e)
      }
})

// Update food in cart
app.post('/api/update-cart-item', async (req, res) => {

    try {
        const { id,quantity ,price } = req.body;
        const data = {
            quantity,
            price: parseInt(price)*quantity
        }
        const getid = await FoodList.findById(id);
        const result = await CartList.updateOne({ food_id : getid._id }, data);
        res.json(result);
    }
    catch (e){
        console.log(e)
    }
})

// add food in cart
app.post('/api/add-cart-item', async (req, res) => {

    try {
        const { _id, price,quantity} = req.body.item;
        const getid = await FoodList.findById(_id);
        if(getid){
            const cartList = new CartList({
                food_id: getid._id,
                price: price,
                quantity: quantity
            })
             const resData = await cartList.save();
            res.json(resData);
        }
    }
    catch (e){
        console.log(e)
    }
})

const port = process.env.PORT || 3000;

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});