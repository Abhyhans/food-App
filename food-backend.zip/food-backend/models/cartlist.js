const mongoose = require('mongoose');

const foodListSchema = new mongoose.Schema({
    food_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'FoodList',
        required: true,
    },
    quantity: Number,
    quantity_food_price:Number,
    date: { type: Date, default: Date.now }
});

const CartList = mongoose.model('cartlists', foodListSchema);

module.exports = CartList;