const mongoose = require('mongoose');

const foodListSchema = new mongoose.Schema({
    name: String,
    price: Number,
    created_at: { type: Date, default: Date.now }
});

const FoodList = mongoose.model('food_lists', foodListSchema);

module.exports = FoodList;